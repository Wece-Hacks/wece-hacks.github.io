# wecehacks.github.io
Website frontend for WECE HACKS
* Pages of the website frontend can be delegated to interested commitee members
* current goal: finalize color scheme and website layout (first done on figmajam, then on vscode)
* run virtual enviroment to view webpage for now


ORDER TO PUSH CODE:

git pull

git add .

git commit -m "message goes here"

git push